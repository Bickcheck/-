/***********************************

> 应用名称：Nicegram
> 软件版本：1.3.8
> 脚本作者：ddgksf2013
> 微信账号：墨鱼手记
> 更新时间：2023-08-19
> 通知频道：https://t.me/ddgksf2021
> 贡献投稿：https://t.me/ddgksf2013_bot
> 问题反馈：ddgksf2013@163.com
> 特别提醒：如需转载请注明出处，谢谢合作！
> 特别说明：⚠️⚠️⚠️
          本脚本仅供学习交流使用，禁止转载售卖
          ⚠️⚠️⚠️


[rewrite_local]
  
# > Nicegram☆解锁会员权限（2023-08-19）@ddgksf2013
https?:\/\/restore-access\.indream\.app\/restoreAccess\?id=\d{5,10} url echo-response text/json echo-response https://github.com/ddgksf2013/dev/raw/main/NicegramProCrack.js


[mitm] 

hostname=restore-access.indream.app

***********************************/



