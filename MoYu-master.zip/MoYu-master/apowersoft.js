/***********************************

> 应用名称：傲软抠图
> 软件版本：1.6.5
> 下载地址：https://apps.apple.com/cn/app/id1490054676
> 脚本作者：Cuttlefish
> 微信账号：墨鱼手记
> 更新时间：2023-03-19
> 通知频道：https://t.me/ddgksf2021
> 问题反馈：https://t.me/ddgksf2013_bot
> 特别说明：本脚本仅供学习交流使用，禁止转载售卖
 
[rewrite_local]

# ～ 傲软抠图解锁会员权限（2023-03-19）@ddgksf2013
https://awvp.aoscdn.com/base/vip/v2/vips url script-response-body apowersoft.js

[mitm] 

hostname=awvp.aoscdn.com

***********************************/





var ddgksf2013={status:200,message:"success",data:{group_expired_at:0,is_tried:0,max_devices:1,period_type:"active",candy_expired_at:0,pending:0,remained_seconds:0,limit:0,expired_at:4045798296,candy:0,license_type:"premium",quota:0,status:1,coin:100}};$done({body:JSON.stringify(ddgksf2013)});
