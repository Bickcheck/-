/***********************************

> 应用名称：小明计算器
> 软件版本：2.2
> 下载地址：https://apps.apple.com/cn/app/id1596875771
> 脚本作者：Cuttlefish
> 微信账号：墨鱼手记
> 更新时间：2023-04-05
> 通知频道：https://t.me/ddgksf2021
> 问题反馈：https://t.me/ddgksf2013_bot
> 特别说明：本脚本仅供学习交流使用，禁止转载售卖
 
[rewrite_local]

# ～ 小明计算器解锁会员权限（2023-04-05）@ddgksf2013
^http:\/\/jsq\.mingcalc\.cn\/XMGetMeCount\.ashx url script-response-body https://github.com/ddgksf2013/MoYu/raw/master/xmcalculator.js


***********************************/





var ddgksf2013={
  "des" : "",
  "result" : {
    "Token" : "ddgksf2013",
    "VipEnd" : "1893340800",
    "VipEndDes" : "2029-12-31 23:59:59"
  },
  "code" : 1
};$done({body:JSON.stringify(ddgksf2013)});
