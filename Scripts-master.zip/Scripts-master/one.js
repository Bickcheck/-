/***********************************************

> 应用名称：One成人的世界一个就够了
> 脚本作者：@ddgksf2013
> 下载地址：https://apps.apple.com/cn/app/id6456038162
> 微信账号：墨鱼手记
> 更新时间：2023-08-10
> 通知频道：https://t.me/ddgksf2021
> 贡献投稿：https://t.me/ddgksf2013_bot
> 问题反馈：ddgksf2013@163.com
> 特别提醒：如需转载请注明出处，谢谢合作！
> 脚本说明：去除开屏广告
> 官网地址：https://one55.app
> 变身秘钥：#iPhone#GOjZ3kxlNw9pD0sdP0WZ9eRS8BKzi+lL5kncO2lE5JDQen0JqaYdRc7nUX4HMjF5X8wMnf0Rrx2GC9eQq5kh78VeRoGLzUYE2TLrKRc2kwj4KhtwzV0p/Hj3N0958WIauFxhElkxyahM1iQwhONfqK/H0QLFNZYVMAbGMSov7c6kZFp5kIT1ZIHjYe66xyK9MhdqETMaiKaHoACE0uQZ78/z292KK6pkjCGA7yUAES1srvQvGaJQJsgaKiYcDIdFtyMATuUAnWptlVoS0s8/Zy66QwBN/dAjTuYrS6Pyk6BXDPdt36RW7EwP536cXpPjisSxh1ni3qchHul43bHtlzWktxtWHinCAVW/exO/XqsoYdODfYurnWNH6MO1lKUUDfgJbWd5Wb5gS9ycgaRN956xcGyocd0+hXqLZTD0AJ/VjQJNtCFv1yFEOnlDxFQUiakGvZ3uo6ac4q1EVyCdvbIt2W+Gc1QVrqypdRWW3yB0vah7NB7rdQPqTwL9GRoERq5a4iMCEqo7FgnPgJalRw==#iPhone#
> 使用说明：复制上面的秘钥，打开马甲APP，即可

[rewrite_local]

^https?:\/\/api\.[a-zA-Z0-9-]+\.com\/.*\/ad\/space url reject-200

[mitm]

hostname = api.6ca2c98.com, api.988068b.com, api.a94e15d.com, api.b33762e.com, api.3h6bljel.com, api.549p0fze.com, api.d154gvlq.com, api.0qda82zu.com,api.fua89ibo.com

***********************************************/
