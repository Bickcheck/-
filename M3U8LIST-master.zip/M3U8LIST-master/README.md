## [墨鱼手记](https://t.me/ddgksf2021)

> 一些关于直播源的使用网址

### 1、直播源列表格式转换 - 黑鸟博客

https://guihet.com/tvlistconvert.html

### 2、EPG的频道LOGO列表，实时更新

http://epg.51zmt.top:8000/

### 3、IPTV链接搜索引擎:

https://www.foodieguide.com/iptvsearch/

### 4、播放工具推荐

https://apps.apple.com/cn/app/id1613758141

### 5、自用直播源
18+（8145个频道）
```
https://raw.githubusercontent.com/YanG-1989/m3u/main/Adult.m3u
```
IPV6超清（92个频道）
```
https://raw.githubusercontent.com/YueChan/IPTV/main/IPTV.m3u
```
IPTV源1080（70个频道）
```
https://github.com/ddgksf2013/M3U8LIST/raw/master/IPTV2022.m3u
```
肥羊百视通（94个频道）
```
https://raw.githubusercontent.com/youshandefeiyang/IPTV/main/main/bestv.m3u
```
owen2000（201个频道）
```
https://jihulab.com/owen2000wy/owentv/-/raw/main/HP20230319.m3u
```
